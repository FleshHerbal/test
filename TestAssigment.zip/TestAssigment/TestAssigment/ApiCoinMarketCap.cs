﻿using RestSharp;
using TestAssigment.Models;
using Newtonsoft.Json;
using System.Net;

namespace TestAssigment
{
    public class ApiCoinMarketCap
    {
        protected string ApiKey { get { return "6f9138b6-422d-4ef7-a679-a401fa7225ae"; } }

        private RestClient Rest_Client;
        private RestRequest SendRequest;

        public IRestResponse ConnectToApi()
        {
            string path = "https://pro-api.coinmarketcap.com/v1/cryptocurrency/listings/latest";

            Rest_Client = new RestClient(path);
            SendRequest = new RestRequest(Method.GET);

            SendRequest.AddHeader("X-CMC_PRO_API_KEY", ApiKey)
                .AddHeader("Accepts", "application/json");

            return Rest_Client.Execute(SendRequest);
        }

        public ModelJson DataOfJson(IRestResponse jsonResult) 
        {
            ModelJson result = JsonConvert.DeserializeObject<ModelJson>(jsonResult.Content);
            return result;
        }

        public bool ThisImage(string path)
        {
            Rest_Client = new RestClient(path);
            SendRequest = new RestRequest(Method.GET);

            SendRequest.AddHeader("Host", "cryptologos.cc");

            IRestResponse response = Rest_Client.Execute(SendRequest);
            var result = response.StatusCode;

            if (result != HttpStatusCode.OK)
            {
                return false;
            }
            else
                return true;
        }
    }
}
 