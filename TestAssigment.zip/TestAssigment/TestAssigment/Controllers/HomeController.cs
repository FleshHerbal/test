﻿using System.Linq;
using Microsoft.AspNetCore.Mvc;
using TestAssigment.Models;
using Microsoft.AspNetCore.Http;

namespace TestAssigment.Controllers
{
    public class HomeController : Controller
    {
        private UserDB Db;
        public HomeController(UserDB _db)
        {
            Db = _db;
        }
        public IActionResult Index()
        {
            bool checkingSession = CheckingSession();
            switch (checkingSession) 
            {
                case false:
                    PartialView(ViewData["pview"] = "NotAuth");
                    break;
                case true:
                    return LocalRedirect("~/getdata/1");
            }
            return View();
        }

        [HttpGet("/getdata/{numberPage}")]
        public IActionResult CurrencyQuotes([FromQuery(Name = "sorting")] string sorting, int numberPage = 1) 
        {
            if (CheckingSession() == false) return Redirect("~/");

            int pageSize = 15;
            ApiCoinMarketCap api = new ApiCoinMarketCap();
            IOrderedEnumerable<Base> data;

            var result = api.DataOfJson(api.ConnectToApi());
            var elem = result.Data.Skip((numberPage - 1) * pageSize).Take(pageSize).ToList();

            ViewBag.amountElem = result.Data.Length / 13;
            
            if (sorting != null)
            {
                switch (sorting)
                {
                    case "AscenOrPriceUp":
                        data = from _data in elem orderby _data.Quote["USD"].Price  ascending select _data;
                        ViewBag.api = data;
                        break;
                    case "AscenOrPriceDown":
                        data = from _data in elem orderby _data.Quote["USD"].Price descending select _data;
                        ViewBag.api = data;
                        break;
                    case "AscenOrNameUp":
                        data = from _data in elem orderby _data.Name, _data.Symbol ascending select _data;
                        ViewBag.api = data;
                        break;
                    case "AscenOrNameDown":
                        data = from _data in elem orderby _data.Name, _data.Symbol descending select _data;
                        ViewBag.api = data;
                        break;
                    case "AscenOrMCUp":
                        data = from _data in elem orderby _data.Quote["USD"].MarketCap ascending select _data;
                        ViewBag.api = data;
                        break;
                    case "AscenOrMCDown":
                        data = from _data in elem orderby _data.Quote["USD"].MarketCap descending select _data;
                        ViewBag.api = data;
                        break;
                    case "AscemOrTimeUp":
                        data = from _data in elem orderby _data.Quote["USD"].LastUpdated ascending select _data;
                        ViewBag.api = data;
                        break;
                    case "AscemOrTimeDown":
                        data = from _data in elem orderby _data.Quote["USD"].LastUpdated descending select _data;
                        ViewBag.api = data;
                        break;
                    default: break;
                }
                
            }
            else { ViewBag.api = elem; }
            return View();
        }
        private bool CheckingSession()
        {
            bool result = false;

            string sessionName = HttpContext.Session.GetString("name");
            if (sessionName != null) result = Db.Users.Any(data => data.Email == sessionName);

            return result;
        }
    }
}
