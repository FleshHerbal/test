﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using TestAssigment.Models;

namespace TestAssigment.Controllers
{
    public class RegistrationController : Controller
    {
        private readonly UserDB Db;
        public RegistrationController(UserDB _db)
        {
            Db = _db;

            if (!_db.Users.Any())
            {
                _db.SaveChanges();
            }
        }

        [HttpGet("/regist")]
        public ActionResult Registration()
        {
            return View();
        }
        
        [HttpGet("/login")]
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost("/regist")]
        public IActionResult Registration(string email, string password, string checkPassword)
        {
            if ((email == null) || (password == null))
            {
                ViewBag.Message = "Не хватает данных!";
                return View();
            }
            else if (password != checkPassword)
            {
                ViewBag.Message = "Введённые пароли не совпадают!";
                return View();
            }
            else
                Db.Users.Add(new UsersModel { PassWord = password, Email = email });
            Db.SaveChanges();
            return View();
        }

        [HttpPost("/login")]
        public IActionResult Login(string email, string password)
        {
            if (HttpContext.Request.Cookies["email"] == null)
            {
                var searchByEmail = Db.Users.Any(data => data.Email == email);
                var searchByPassword = Db.Users.Any(data => data.PassWord == password);

                if (searchByEmail == false || searchByPassword == false)
                {
                    ViewBag.Message = "Пользователя с такими данными не существует!";
                }
                else
                    ViewBag.Message = "Вы авторизованны!";

                HttpContext.Response.Cookies.Append("email", email);
                HttpContext.Response.Cookies.Append("password", password);
                HttpContext.Session.SetString("name", email.ToString());
            }
            else if (HttpContext.Request.Cookies["email"] != null)
            {
                ViewBag.Message = "Вы авторизованны!";
            }

            return View();
        }
       
    }
}
