﻿using Newtonsoft.Json;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace TestAssigment.Models
{
    public class ModelJson
    {
        [JsonPropertyName("data")]
        public Base[] Data { get; set; }
    }
    public class Base
    {
        [JsonProperty("id")]
        public int Id { get; set; }
        [JsonProperty("name")]
        public string Name { get; set; }
        [JsonProperty("slug")]
        public string Slug { get; set; }
        [JsonProperty("symbol")]
        public string Symbol { get; set; }
        [JsonProperty("quote")]
        public Dictionary<object, USD> Quote { get; set; }
        /*public Dictionary<string, USD> Quote { get; set; }*/
        
    }
    public class USD 
    {
        [JsonProperty("price")]
        public decimal Price { get; set; }
        [JsonProperty("percent_change_1h")]
        public decimal ChangesHour { get; set; }
        [JsonProperty("percent_change_24h")]
        public decimal ChangesDay { get; set; }
        [JsonProperty("percent_change_7d")]
        public decimal ChangesWeek { get; set; }
        [JsonProperty("market_cap")]
        public decimal MarketCap { get; set; }
        [JsonProperty("last_updated")]
        public string LastUpdated { get; set; }
    }
}
