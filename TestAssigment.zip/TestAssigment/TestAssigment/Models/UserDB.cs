﻿using System;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;

namespace TestAssigment.Models
{
    public class UserDB : DbContext
    {
        public DbSet<UsersModel> Users { get; set; }

        public UserDB(DbContextOptions<UserDB> context) : base(context) 
        {
            /*Database.EnsureDeleted();*/
            Database.EnsureCreated();
        }
    }
}
