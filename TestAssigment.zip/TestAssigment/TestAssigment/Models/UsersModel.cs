﻿using System.ComponentModel.DataAnnotations;

namespace TestAssigment.Models
{
    public class UsersModel
    {
        [Key]
        public int Id { get; set; }
        [Required] 
        [MinLength(5)]
        public string Email { get; set; }
        [Required]
        [MinLength(6)]
        public string PassWord { get; set; }
    }
}
