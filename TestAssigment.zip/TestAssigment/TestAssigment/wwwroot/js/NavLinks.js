﻿navMain = () => {
    document.location.replace(window.location.href = "/");
};
navLogin = () => {
    document.location.replace(window.location.href = "/login");
};
navRegist = () => {
    document.location.replace(window.location.href = "/regist");
};
Pagination = (number) => {
    document.location.replace("/getdata/" + number.toString());
};
ClickBlock = (elem) => {
    var blockElem = document.getElementById("block" + elem + "Elem");
    blockElem.style.display = "block";
};