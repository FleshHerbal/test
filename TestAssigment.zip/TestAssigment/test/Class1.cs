﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace test
{
   

    public class Status
    {
        [JsonPropertyName("timestamp")]
        public DateTime Timestamp { get; set; }

        [JsonPropertyName("error_code")]
        public int ErrorCode { get; set; }

        [JsonPropertyName("elapsed")]
        public int Elapsed { get; set; }

        [JsonPropertyName("credit_count")]
        public int CreditCount { get; set; }

        [JsonPropertyName("total_count")]
        public int TotalCount { get; set; }
    }

    public class QuoteForCurrency
    {
        [JsonPropertyName("price")]
        public decimal Price { get; set; }

        [JsonPropertyName("volume_24h")]
        public decimal Volume24h { get; set; }

        [JsonPropertyName("percent_change_1h")]
        public decimal PercentChange1h { get; set; }

        [JsonPropertyName("percent_change_24h")]
        public decimal PercentChange24h { get; set; }

        [JsonPropertyName("percent_change_7d")]
        public decimal PercentChange7d { get; set; }

        [JsonPropertyName("percent_change_30d")]
        public decimal PercentChange30d { get; set; }

        [JsonPropertyName("percent_change_60d")]
        public decimal PercentChange60d { get; set; }

        [JsonPropertyName("percent_change_90d")]
        public decimal PercentChange90d { get; set; }

        [JsonPropertyName("market_cap")]
        public decimal MarketCap { get; set; }

        [JsonPropertyName("last_updated")]
        public DateTime LastUpdated { get; set; }
    }

    public class Platform
    {
        [JsonPropertyName("id")]
        public int Id { get; set; }

        [JsonPropertyName("name")]
        public string Name { get; set; }

        [JsonPropertyName("symbol")]
        public string Symbol { get; set; }

        [JsonPropertyName("slug")]
        public string Slug { get; set; }

        [JsonPropertyName("token_address")]
        public string TokenAddress { get; set; }
    }

    public class Item
    {
        [JsonPropertyName("id")]
        public int Id { get; set; }

        [JsonPropertyName("name")]
        public string Name { get; set; }

        [JsonPropertyName("symbol")]
        public string Symbol { get; set; }

        [JsonPropertyName("slug")]
        public string Slug { get; set; }

        [JsonPropertyName("num_market_pairs")]
        public int NumMarketPairs { get; set; }

        [JsonPropertyName("date_added")]
        public DateTime DateAdded { get; set; }

        [JsonPropertyName("tags")]
        public List<string> Tags { get; set; }

        [JsonPropertyName("max_supply")]
        public int MaxSupply { get; set; }

        [JsonPropertyName("circulating_supply")]
        public decimal CirculatingSupply { get; set; }

        [JsonPropertyName("total_supply")]
        public decimal TotalSupply { get; set; }

        [JsonPropertyName("cmc_rank")]
        public int CmcRank { get; set; }

        [JsonPropertyName("last_updated")]
        public DateTime LastUpdated { get; set; }

        [JsonPropertyName("quote")]
        public Dictionary<string, QuoteForCurrency> Quote { get; set; }

        [JsonPropertyName("platform")]
        public Platform Platform { get; set; }
    }

    public class Response
    {
/*        [JsonPropertyName("status")]
        public Status Status { get; set; }*/

        [JsonPropertyName("data")]
        public List<Item> Data { get; set; }
    }
}
