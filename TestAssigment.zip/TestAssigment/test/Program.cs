﻿using RestSharp;
using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using TestAssigment.Models;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            Program program = new Program();
            Console.WriteLine("Hello World!");
            program.DataOfJson();
        }
        protected string ApiKey { get { return "6f9138b6-422d-4ef7-a679-a401fa7225ae"; } }

        private IRestResponse ConnectToApi()
        {
            string path = "https://pro-api.coinmarketcap.com/v1/cryptocurrency/listings/latest";

            RestClient restClient = new RestClient(path);
            RestRequest sendRequest = new RestRequest(Method.GET);

            sendRequest.AddHeader("X-CMC_PRO_API_KEY", ApiKey)
                .AddHeader("Accepts", "application/json");

            return restClient.Execute(sendRequest);
        }

        public void DataOfJson()
        {
            var jsonResult = ConnectToApi();

            ModelJson result = JsonConvert.DeserializeObject<ModelJson>(jsonResult.Content);
            Console.WriteLine(result.Data[1].Symbol);
            Console.ReadLine();
        }
    }
}
